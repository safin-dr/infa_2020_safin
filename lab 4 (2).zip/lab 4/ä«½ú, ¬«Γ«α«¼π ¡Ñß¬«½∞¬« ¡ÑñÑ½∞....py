import os
import pygame as pg

import random as rnd
from random import randint
import sys


class Ball:
    '''
    Çàäà¸ì êëàññ øàðèêîâ, îáëàäàþùèé îïðåäåëåííûìè ñâîéñòâàìè
    '''

    def __init__(self, x, y, dx, dy, image):
        '''
        Èíèöèàëèçàöèÿ øàðèêà - íåîáõîäèìà äëÿ åãî ñîçäàíèÿ
        x, y - ïðîèçâîëüíûå êîîðäèíàòû ñòàðòà øàðèêà
        dx, dy - ñìåùåíèå øàðèêà çà îäíó èòåðàöèþ
        image - âíåøíèé âèä øàðèêà
        '''
        # print(x, y, dx, dy)
        self.img = pg.transform.scale(image, (150, 150))
        self.dx = dx
        self.dy = dy
        self.rect = screen.blit(self.img, (x, y))
        return

    def show(self):
        '''
        Ôóíêöèÿ, ïîêàçûâàþùàÿ øàðèê
        '''
        screen.blit(self.img, self.rect)

    def move(self):
        '''
        Îòâå÷àåò çà ïåðåìåùåíèå øàðèêà â êàæäîé èòåðàöèè
        '''
        self.rect = self.rect.move([self.dx, self.dy])
        self.show()
        return

    def check_collide_with_walls(self, left_x, right_x, top_y, bottom_y):
        '''
        Ôóíêöèÿ îòâå÷àåò çà îòðàæåíèå øàðèêà îò ñòåíû
        left_x, right_x, top_y, bottom_y - ãðàíèöû êàðòèíêè
        '''
        if self.rect.left < left_x or self.rect.right > right_x:
            self.dx *= -1

        if self.rect.top < top_y or self.rect.bottom > bottom_y:
            self.dy *= -1
        return

    def check_click(self, coords):
        '''
        Âûäà¸ò î÷êè â çàâèñèìîñòè îò ïîïàäàíèÿ
        '''
        if self.rect.left < coords[0] and self.rect.right > coords[0] and self.rect.top < coords[
            1] and self.rect.bottom > coords[1]:
            self.x = randint(120, 860)
            self.y = randint(120, 460)
            return True

        return False


''' Çàäà¸ì èñõîäíûå äàííûå'''

pg.init()
size = width, height = 1000, 600
white = 255, 255, 255

screen = pg.display.set_mode(size)
font = pg.font.Font(None, 50)

balls_array = []
balls_n = 4
images = ['fresco.jpg', 'cat.jpg', 'dgap.jpg', 'sponge.jpg', 'rat.jpg']

##########!!!!!!!!!!!!!
game_folder = os.path.dirname(__file__)
img_folder = os.path.join(game_folder, 'images')
##########!!!!!!!!!!!!!

'''Öèêë, çàäàþùèé íåîáõîäèìîå êîëè÷åñòâî øàðèêîâ è ìèøåíåé'''
for i in range(balls_n):
    balls_array.append(Ball(randint(100, width - 100),
                            randint(100, height - 100),
                            randint(9, 14),
                            randint(8, 13),
                            pg.image.load(os.path.join(img_folder, images[randint(0, 4)]))))

clock = pg.time.Clock()

score = 0
change = 1
name = input()

while True:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()
        elif event.type == pg.MOUSEBUTTONDOWN:
            for ball in balls_array:
                if ball.check_click(event.pos):
                    ball.x = randint(100, 900)
                    ball.y = randint(100, 500)
                    score += randint(5, 8)
                    break
                else:
                    score -= 1

    if change % 10 == 1:
        color = randint(0, 255), randint(0, 255), randint(0, 255)
        for ball in balls_array:
            ball.dx += score // 10 * (-1) ** randint(0, 1)
            ball.dy += score // 10 * (-1) ** randint(0, 1)
    change += 1
    screen.fill(color)

    for ball in balls_array:
        ball.move()
        ball.check_collide_with_walls(0, width, 0, height)

    dfont = font.render('Score: ' + str(score), False, (0, 0, 0))
    screen.blit(dfont, (0, 0))
    pg.display.update()
    pg.display.flip()
    clock.tick(30)

pg.quit()
l_list = open('leaders.txt', 'a')
print(name + ': ' + str(score), file=l_list)
l_list.close()
